﻿CREATE TABLE `member` (
	`member_id`	int	NOT NULL,
	`username`	varchar(30)	NOT NULL,
	`password`	varchar(255)	NOT NULL,
	`email`	varchar(30)	NOT NULL,
	`authority`	varchar(20)	NOT NULL
);

ALTER TABLE `member` ADD CONSTRAINT `PK_MEMBER` PRIMARY KEY (
	`member_id`
);

