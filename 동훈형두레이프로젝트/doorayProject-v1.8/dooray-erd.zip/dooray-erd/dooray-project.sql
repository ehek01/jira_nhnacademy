﻿CREATE TABLE `project` (
	`project_id`	int	NOT NULL,
	`member_id`	int	NOT NULL,
	`project_name`	varchar(30)	NOT NULL,
	`project_status`	varchar(30)	NOT NULL,
	`create_dt`	date	NOT NULL
);

CREATE TABLE `task` (
	`task_id`	int	NOT NULL,
	`project_id`	int	NOT NULL,
	`member_id`	int	NOT NULL,
	`task_name`	varchar(30)	NULL,
	`milestone`	varchar(30)	NULL,
	`create_dt`	datetime	NOT NULL,
	`expected_complete_dt`	datetime	NULL,
	`completed_dt`	datetime	NULL
);

CREATE TABLE `tag` (
	`tag_id`	int	NOT NULL,
	`task_id`	int	NOT NULL,
	`tag_name`	varchar(30)	NOT NULL
);

CREATE TABLE `comment` (
	`comment_id`	int	NOT NULL,
	`task_id`	int	NOT NULL,
	`member_id`	int	NOT NULL,
	`content`	varchar(255)	NOT NULL,
	`create_dt`	datetime	NOT NULL,
	`modified_dt`	datetime	NULL,
	`member_id2`	int	NOT NULL
);

CREATE TABLE `projectMember` (
	`member_id`	int	NOT NULL,
	`adminyn`	varchar(1)	NOT NULL
);

ALTER TABLE `project` ADD CONSTRAINT `PK_PROJECT` PRIMARY KEY (
	`project_id`,
	`member_id`
);

ALTER TABLE `task` ADD CONSTRAINT `PK_TASK` PRIMARY KEY (
	`task_id`
);

ALTER TABLE `tag` ADD CONSTRAINT `PK_TAG` PRIMARY KEY (
	`tag_id`
);

ALTER TABLE `comment` ADD CONSTRAINT `PK_COMMENT` PRIMARY KEY (
	`comment_id`
);

ALTER TABLE `projectMember` ADD CONSTRAINT `PK_PROJECTMEMBER` PRIMARY KEY (
	`member_id`
);

ALTER TABLE `project` ADD CONSTRAINT `FK_projectMember_TO_project_1` FOREIGN KEY (
	`member_id`
)
REFERENCES `projectMember` (
	`member_id`
);

